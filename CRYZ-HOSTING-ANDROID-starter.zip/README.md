# CRYZ HOSTING ANDROID

Early Android interface prototype for a community-powered Minecraft Bedrock hosting app.

## Current status
- Android app interface prototype
- GitHub Actions workflow for building a debug APK
- Real server engine and Start/Stop controls are not connected yet

This first APK is a UI demo, not a working Minecraft server host. A compatible Bedrock server engine, Android foreground-service handling, and networking solution must be tested before real hosting works.

## Build
Upload/push this project to the repository's `main` branch. Open **Actions**, select the latest successful **Build CRYZ HOSTING APK** run, and download the `cryz-hosting-debug-apk` artifact.

## Security
Never commit passwords, API keys, private tokens, or personal data to this public repository.
